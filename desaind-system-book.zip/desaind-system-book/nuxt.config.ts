// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  compatibilityDate: '2025-07-15',
  devtools: { enabled: true },
  i18n: {
    defaultLocale: 'en',
    langDir: '../layers/i18n/locales',
    locales: [
      { code: 'en', file: 'en/core.json', language: 'en-US' },
    ],
  },
  modules: [
    '@unocss/nuxt',
    '@nuxtjs/i18n',
  ],
});
