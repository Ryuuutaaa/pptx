import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { defineConfig } from 'unocss';
import {
  bookingRules,
  bookingShortcuts,
  coreTheme,
  extractorBrandColors,
  preflightCssVariables,
  presetVinicuncaConfig,
} from './app/designs/unocss';

export default defineConfig({
  configDeps: getAllConfigFiles('./app/designs/unocss'),

  presets: [
    presetVinicuncaConfig,
  ],

  extractors: [
    extractorBrandColors,
  ],

  theme: coreTheme,

  layers: {
    pohon: 20,
  },

  outputToCssLayers: true,

  preflights: [
    preflightCssVariables,
  ],

  rules: [
    ...bookingRules,
  ],

  safelist: [
    'isolate',
    // We need to output the css variables for all the primary colors
    'bg-primary-100',
    'bg-primary-200',
    'bg-primary-300',
    'bg-primary-400',
    'bg-primary-500',
    'bg-primary-600',
    'bg-primary-700',
    'bg-primary-800',
    'bg-primary-900',
    'bg-primary-950',
    'color-slate-50',
    'color-slate-100',
    'color-slate-200',
    'color-slate-300',
    'color-slate-400',
    'color-slate-500',
    'color-slate-600',
    'color-slate-700',
    'color-slate-800',
    'color-slate-900',
  ],

  shortcuts: {
    ...bookingShortcuts,
  },
});

function getAllConfigFiles(dir: string) {
  const root = process.cwd();
  const dirFull = path.join(root, dir);

  if (!fs.existsSync(dirFull)) {
    return [];
  }

  const files = fs.readdirSync(dirFull);
  return files.filter((file: string) => path.extname(file) === '.ts').map((file: string) => path.join(dir, file));
}
