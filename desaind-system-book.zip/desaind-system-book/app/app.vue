<template>
  <div class="text-text p-10 bg-background flex flex-col min-h-screen items-center justify-center">
    <h1 class="text-heading-section-bold text-primary-500">
      {{ $t("seo.title") }}
    </h1>
  </div>
</template>

<style>
:root {
  --pohon-header-height: 64px;
}
</style>
