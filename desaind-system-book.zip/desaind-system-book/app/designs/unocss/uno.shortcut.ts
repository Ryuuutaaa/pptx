import type { UserShortcuts } from 'unocss';

export const bookingShortcuts: UserShortcuts = {
  /**
   *********************
   * Typography
   *********************
   */
  'text-caption-label-medium': 'text-caption-label font-medium',
  'text-caption-label-semibold': 'text-caption-label font-semibold',
  'text-caption-label-bold': 'text-caption-label font-bold',

  'text-body-medium': 'text-body font-medium',
  'text-body-semibold': 'text-body font-semibold',
  'text-body-bold': 'text-body font-bold',

  'text-subheading-medium': 'text-subheading font-medium',
  'text-subheading-semibold': 'text-subheading font-semibold',
  'text-subheading-bold': 'text-subheading font-bold',

  'text-body-lead-medium': 'text-body-lead font-medium',
  'text-body-lead-semibold': 'text-body-lead font-semibold',
  'text-body-lead-bold': 'text-body-lead font-bold',

  'text-heading-card-medium': 'text-heading-card font-medium',
  'text-heading-card-semibold': 'text-heading-card font-semibold',
  'text-heading-card-bold': 'text-heading-card font-bold',

  'text-heading-subtitle-medium': 'text-heading-subtitle font-medium',
  'text-heading-subtitle-semibold': 'text-heading-subtitle font-semibold',
  'text-heading-subtitle-bold': 'text-heading-subtitle font-bold',

  'text-heading-title-medium': 'text-heading-title font-medium',
  'text-heading-title-semibold': 'text-heading-title font-semibold',
  'text-heading-title-bold': 'text-heading-title font-bold',

  'text-heading-section-medium': 'text-heading-section font-medium',
  'text-heading-section-semibold': 'text-heading-section font-semibold',
  'text-heading-section-bold': 'text-heading-section font-bold',

  'text-display-hero-sm-medium': 'text-display-hero-sm font-medium',
  'text-display-hero-sm-semibold': 'text-display-hero-sm font-semibold',
  'text-display-hero-sm-bold': 'text-display-hero-sm font-bold',

  'text-display-hero-1-medium': 'text-display-hero-1 font-medium',
  'text-display-hero-1-semibold': 'text-display-hero-1 font-semibold',
  'text-display-hero-1-bold': 'text-display-hero-1 font-bold',

  'text-display-hero-2-medium': 'text-display-hero-2 font-medium',
  'text-display-hero-2-semibold': 'text-display-hero-2 font-semibold',
  'text-display-hero-2-bold': 'text-display-hero-2 font-bold',

  /**
   *********************
   * Gradients
   *********************
   */
  // isolate here needed to make the component that using this class to create its own stacking context to make the border stay. This is caused by the -z-1 class
  'border-gradient-primary': 'border-gradient-mask isolate relative before:(p-[2px] rounded-inherit content-empty absolute inset-0 -z-1 from-primary-500/32 to-primary-500/32 via-primary-500/10 bg-gradient-to-b pointer-events-none)',
  // Background gradient
  'gradient-dark-card': 'bg-gradient-to-br from-primary/8 via-primary/12 to-primary/16',
  'gradient-dark-line': 'bg-gradient-to-b from-neutral-800 to-white',

  'gradient-primary': 'bg-gradient-to-b from-[#3BC3FF] to-[#1A8CFF]',
  'gradient-hover': 'bg-gradient-to-b from-[#1FB6FF] to-[#0077FF]',
  'gradient-active': 'bg-gradient-to-b from-[#0A9DFF] to-[#0062D6]',
  'gradient-dark': 'bg-gradient-to-tr from-neutral from-30%  to-primary-325/15',
};
