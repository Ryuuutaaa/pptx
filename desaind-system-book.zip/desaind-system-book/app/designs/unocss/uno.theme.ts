import type { VinicuncaTheme } from '@vinicunca/unocss-preset';

export const coreTheme: VinicuncaTheme = {
  colors: {
    primary: {
      50: 'oklch(96.47% 0.020 233.85)', // #e7f6ff (primary-lighter)
      100: 'oklch(95.05% 0.028 233.64)', // #d6f0ff
      200: 'oklch(93.64% 0.037 233.44)', // #ceedff (primary-light)
      300: 'oklch(88.18% 0.067 235.73)', // #a3dcff
      400: 'oklch(78.69% 0.120 240.52)', // #58c5ff
      500: 'oklch(69.19% 0.173 245.30)', // #0aa3ff (primary-base)
      600: 'oklch(62.84% 0.157 245.14)', // #0093ec
      700: 'oklch(56.49% 0.140 244.97)', // #0772b3 (primary-dark)
      800: 'oklch(45.66% 0.115 244.97)', // #005a90
      900: 'oklch(30.33% 0.083 245.14)', // #003c62
      950: 'oklch(15.00% 0.050 245.30)', // #001f35
      DEFAULT: 'oklch(69.19% 0.173 245.30)',
    },

    neutral: {
      50: 'oklch(98.00% 0.005 245.30)', // #f9fbfc
      100: 'oklch(97.48% 0.004 245.30)', // #f3f4f6 (text-primary)
      200: 'oklch(96.96% 0.003 245.30)', // #f1f2f3
      300: 'oklch(90.41% 0.008 245.30)', // #e1e3e6
      400: 'oklch(77.84% 0.019 245.30)', // #bdc1c7
      500: 'oklch(65.27% 0.030 245.30)', // #8a8fa3 (muted-text)
      600: 'oklch(49.66% 0.030 245.30)', // #707484
      700: 'oklch(34.05% 0.029 245.30)', // #4a4d5b
      800: 'oklch(22.70% 0.031 245.30)', // #1f2433 (surface/disabled-bg)
      900: 'oklch(15.61% 0.035 245.30)', // #131724
      950: 'oklch(8.52% 0.038 245.30)', // #01010c (background-dark)
    },

    warning: {
      50: 'oklch(97.00% 0.020 90.38)', // #faf5e6
      100: 'oklch(94.90% 0.051 90.38)', // #fbeec8
      200: 'oklch(92.81% 0.083 90.38)', // #fce6a8
      300: 'oklch(90.71% 0.114 90.38)', // #fdde85
      400: 'oklch(88.62% 0.145 90.38)', // #fed55b
      500: 'oklch(86.52% 0.177 90.38)', // #ffcc00
      600: 'oklch(73.22% 0.151 90.38)', // #cda300
      700: 'oklch(59.91% 0.126 90.38)', // #9d7b00
      800: 'oklch(46.61% 0.101 90.38)', // #6f5600
      900: 'oklch(33.30% 0.075 90.38)', // #453400
      950: 'oklch(20.00% 0.050 90.38)', // #1f1400
    },

    error: {
      50: 'oklch(97.00% 0.020 29.23)', // #fff0ed
      100: 'oklch(90.16% 0.068 29.23)', // #ffcfc5
      200: 'oklch(83.32% 0.115 29.23)', // #ffab9d
      300: 'oklch(76.48% 0.163 29.23)', // #ff8674
      400: 'oklch(69.64% 0.210 29.23)', // #ff5a49
      500: 'oklch(62.80% 0.258 29.23)', // #ff0000
      600: 'oklch(54.24% 0.216 29.23)', // #d0110a
      700: 'oklch(45.68% 0.175 29.23)', // #a2150e
      800: 'oklch(37.12% 0.133 29.23)', // #77150e
      900: 'oklch(28.56% 0.092 29.23)', // #4e120c
      950: 'oklch(20.00% 0.050 29.23)', // #290b08
      DEFAULT: 'oklch(62.80% 0.258 29.23)',
    },

    green: {
      500: 'oklch(72% 0.16 164)', // #00C588
    },

    button: {
      base: {
        top: 'oklch(76.24% 0.147 245.30)', // #1fb6ff
        bottom: 'oklch(57.06% 0.187 245.30)', // #0077ff
      },
      hover: {
        top: 'oklch(80.52% 0.128 245.30)', // #3bc3ff
        bottom: 'oklch(62.31% 0.174 245.30)', // #1a8cff
      },
      active: {
        top: 'oklch(69.19% 0.173 245.30)', // #0a9dff
        bottom: 'oklch(50.48% 0.183 245.30)', // #0062d6
      },
    },

    background: {
      accented: 'var(--pohon-bg-accented)',
      border: 'var(--pohon-border)',
      DEFAULT: 'var(--pohon-bg)',
      elevated: 'var(--pohon-bg-elevated)',
      inverted: 'var(--pohon-bg-inverted)',
      muted: 'var(--pohon-bg-muted)',
    },

    text: {
      DEFAULT: 'var(--pohon-text)',
      dimmed: 'var(--pohon-text-dimmed)',
      highlighted: 'var(--pohon-text-highlighted)',
      inverted: 'var(--pohon-text-inverted)',
      muted: 'var(--pohon-text-muted)',
      toned: 'var(--pohon-text-toned)',
    },

    border: {
      accented: 'var(--pohon-border-accented)',
      bg: 'var(--pohon-bg)',
      DEFAULT: 'var(--pohon-border)',
      inverted: 'var(--pohon-border-inverted)',
      muted: 'var(--pohon-border-muted)',
    },

    divide: {
      accented: 'var(--pohon-border-accented)',
      DEFAULT: 'var(--pohon-border)',
      inverted: 'var(--pohon-border-inverted)',
      muted: 'var(--pohon-border-muted)',
    },

    fill: {
      DEFAULT: 'var(--pohon-border)',
      bg: 'var(--pohon-bg)',
      inverted: 'var(--pohon-border-inverted)',
    },

    outline: {
      DEFAULT: 'var(--pohon-border)',
      inverted: 'var(--pohon-border-inverted)',
    },

    ring: {
      accented: 'var(--pohon-border-accented)',
      bg: 'var(--pohon-bg)',
      DEFAULT: 'var(--pohon-border)',
      inverted: 'var(--pohon-border-inverted)',
      muted: 'var(--pohon-border-muted)',
      offset: {
        accented: 'var(--pohon-border-accented)',
        bg: 'var(--pohon-bg)',
        DEFAULT: 'var(--pohon-border)',
        inverted: 'var(--pohon-border-inverted)',
        muted: 'var(--pohon-border-muted)',
      },
    },

    stroke: {
      DEFAULT: 'var(--pohon-border)',
      bg: 'var(--pohon-bg)',
      inverted: 'var(--pohon-border-inverted)',
    },
  },

  text: {
    'caption-label': {
      fontSize: '0.875rem', // 14px
      lineHeight: '1.4',
    },
    'body': {
      fontSize: '1rem', // 16px
      lineHeight: '1.6',
    },
    'subheading': {
      fontSize: '1.125rem', // 18px
      lineHeight: '1.6',
    },
    'body-lead': {
      fontSize: '1.25rem', // 20px
      lineHeight: '1.5',
    },
    'heading-card': {
      fontSize: '1.5rem', // 24px
      lineHeight: '1.3',
    },
    'heading-subtitle': {
      fontSize: '1.75rem', // 28px
      lineHeight: '1.2',
    },
    'heading-title': {
      fontSize: '2rem', // 32px
      lineHeight: '1.2',
    },
    'heading-section': {
      fontSize: '2.25rem', // 36px
      lineHeight: '1.2',
    },
    'display-hero-sm': {
      fontSize: '2.5rem', // 40px
      lineHeight: '1.15',
    },
    'display-hero-1': {
      fontSize: '3rem', // 48px
      lineHeight: '1.1',
    },
    'display-hero-2': {
      fontSize: '4rem', // 64px
      lineHeight: '1.1',
    },
  },

  container: {
    '8xl': '90rem',
  },

  font: {
    sans: 'Inter',
    display: 'Rubik',
    manrope: 'Manrope',
  },

  containers: {
    center: true,
    padding: '1rem',
  },
};
