import type { Rule } from 'unocss';
import { symbols } from 'unocss';

export const bookingRules: Array<Rule> = [
  [
    /^pt-header(?:-(\d+))?$/,
    ([, n]) => ({
      'padding-top': n
        ? `calc(var(--pohon-header-height) + calc(var(--spacing) * ${n}))`
        : 'var(--pohon-header-height)',
    }),
  ],
  [
    'border-gradient-mask',
    [
      {
        [symbols.selector]: (selector) => `${selector}::before`,
        'mask': `
          linear-gradient(var(--colors-neutral-950)) content-box,
          linear-gradient(var(--colors-neutral-950))
        `,
        'mask-composite': 'exclude',
      },
    ],
  ],
];
