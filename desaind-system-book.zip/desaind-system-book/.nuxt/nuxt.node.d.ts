/// <reference types="@unocss/nuxt" />
/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="@nuxtjs/i18n" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference path="../node_modules/.pnpm/@nuxt+vite-builder@4.4.4_@babel+plugin-syntax-jsx@7.28.6_@babel+core@7.29.0__@types+nod_fde62da129639df0dca5f7f260260552/node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../node_modules/.pnpm/@nuxt+nitro-server@4.4.4_@babel+core@7.29.0_db0@0.3.4_ioredis@5.10.1_magicast@0.5.2_nux_3892342c3c5f5ec2662ca33e490b5d3b/node_modules/@nuxt/nitro-server/dist/index.d.mts" />
/// <reference path="types/middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
