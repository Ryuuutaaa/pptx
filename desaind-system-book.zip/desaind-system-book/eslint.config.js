import { vinicuncaESLint } from '@vinicunca/eslint-config';

export default vinicuncaESLint(
  {
    formatters: {
      css: true,
      html: true,
    },
    typescript: true,
    unocss: {
      configPath: './uno.config.ts',
    },
    vue: true,
    pnpm: {
      catalogs: false,
    },
  },

  {
    ignores: [
      '**/*.md',
      '.nuxt/**',
      '.output/**',
      'dist/**',
    ],
  },

  {
    rules: {
      'pnpm/yaml-enforce-settings': 'off',
      'e18e/ban-dependencies': ['off'],
    },
  },

  {
    files: [
      '**/scripts/**',
      '**/server/**',
      '**/playwright.config.ts',
    ],
    rules: {
      'node/prefer-global/process': 'off',
    },
  },

  {
    files: [
      '**/nuxt.config.ts',
    ],
    rules: {
      'perfectionist/sort-objects': 'error',
    },
  },
);
